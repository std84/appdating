import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule, FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import { AuthService } from '../_services/auth.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Output() cancelRegister = new EventEmitter();
  model: any = {};
  submitted = false;
  registerForm: FormGroup;
  constructor( private authService: AuthService, private fb: FormBuilder) { }
  passwordMatchValidator(g: FormGroup) {

    return g.get('password').value === g.get('confirmPassword').value ? null : {'mismatch': true};
}
  ngOnInit() {
    this.createRegisterForm();
  }
  get f() {  return this.registerForm.controls; }
  createRegisterForm() {
    this.registerForm = this.fb.group({
      username: new FormControl('', Validators.required),
      password: new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(8)]),
      confirmPassword: new FormControl('',  [Validators.required, Validators.minLength(4), Validators.maxLength(8)])
    }, {Validators: this.passwordMatchValidator});
  }
  register() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }

     /* this.authService.register(this.model).subscribe(() => {
        console.log('registeraion successfull');
      }, error => { console.log(error); });*/
      console.log(this.registerForm.value);
  }
  cancel() {
    this.cancelRegister.emit(false);
    console.log('cancelled');
  }

}
