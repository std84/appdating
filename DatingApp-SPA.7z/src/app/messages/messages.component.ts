import { Component, OnInit } from '@angular/core';
import { Message } from '../_models/message';
import { Pagination, PaginatedResult } from '../_models/Pagination';
import { UserService } from '../_services/User.service';
import { AlertifyService } from '../_services/alertify.service';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../_services/auth.service';


@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {

  messages: Message[];
  pagination: Pagination;
  messageContainer = 'Unread';

  constructor(private userService: UserService, private authService: AuthService,
    private route: ActivatedRoute,
     private alertify: AlertifyService ) { }
  ngOnInit() {
    this.route.data.subscribe(data => {
     this.messages = data['messages'].result;
     this.pagination = data['messages'].pagination;
    });
  }
  loadMessages() {
    this.userService.getMessages(this.authService.decodedToken.nameid[0], this.pagination.currentPage,
      this.pagination.itemsPerPage, this.messageContainer)
    .subscribe((res: PaginatedResult<Message[]>) => {
      this.messages = res.result;
        this.pagination = res.pagination;
    });
  }
  deleteMessage(id: number) {
    this.alertify.confirm(' are you sure you wnat to delete', () => {
      debugger;
        this.userService.deleteMessage(id, this.authService.decodedToken.nameid[0])
        .subscribe(() => {
          this.messages.splice(this.messages.findIndex(m => m.id === id), 1);
          this.alertify.success('message has deelted');
        }, error => {
          this.alertify.error(error);
        });
    });
  }
  pagedChanged(event: any): void {
    this.pagination.currentPage = event.page;
    this.loadMessages();
  }
}
