import { Component, OnInit, Input, Output , EventEmitter } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {




  values: any;
  registerMode = false;
  model: any = { };
  constructor(private authService: AuthService, private http: HttpClient) { }

  ngOnInit() {
    this.getVAlues();
  }
  registerToggle() {
    this.registerMode = !this.registerMode;
  }
  getVAlues() {
    this.http.get('http://localhost:5000/api/values').subscribe(response => {
      this.values = response; }, error => {console.log(error); });
  }
  cancelRegistermode(registerMode: boolean) {
    this.registerMode = registerMode;
  }
}
