import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';
import { JwtHelperService } from '@auth0/angular-jwt';
import { HttpClientModule } from '@angular/common/http'; import { HttpModule } from '@angular/http';
import { User } from '../_models/User';

@Injectable({
  providedIn: 'root'
})
export class AuthService {


baseurl = environment.apiurl + 'auth/';

  public decodedToken: any;
  jwtHelper = new JwtHelperService();
  currentUser: User;
  photoUrl = new BehaviorSubject<string>('../../assets/user.png');
  currentPhotoUrl = this.photoUrl.asObservable();
  constructor(private http: HttpClient) { }
  changeMemberPhoto(photoUrl: string) {
    this.photoUrl.next(photoUrl);
  }
  Login(model: any) {
    return this.http.post(this.baseurl + 'login', model).pipe(
      map((response: any) => {
        const user = response;
        if (user) {
          localStorage.setItem('token', user.token);
          localStorage.setItem('user', JSON.stringify(user.userFromRepo));
          this.decodedToken = this.jwtHelper.decodeToken(user.token);
          this.currentUser = user.userFromRepo;
          this.changeMemberPhoto(this.currentUser.photoUrl);
          console.log(this.currentUser);
          console.log(user);
        }
      })
    );
  }
  register(model: any) {

    return this.http.post(this.baseurl + 'register', model);
  }
  loggedIn() {
      const token = localStorage.getItem('token');
      return  !this.jwtHelper.isTokenExpired(token);
  }

}
