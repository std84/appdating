using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using DatingApp.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using DatingApp.Api.Helpers;
using CloudinaryDotNet;
using System.Threading.Tasks;
using DatingApp.Api.Dtos;
using System.Security.Claims;
using CloudinaryDotNet.Actions;
using System.Linq;

namespace DatingApp.Api.Controllers
{
    [Authorize]
    [Route("api/users/{userId}/photos")]
    [ApiController]
    public class PhotosController: ControllerBase
    {
        private readonly IDatingRepository _repo;
        private readonly IMapper _mapper;
        private readonly IOptions<CloudinarySettings> _cloudinaryConfig;
        private  Cloudinary _cloudinary ;
        public PhotosController(IDatingRepository repos, IMapper mapper, 
        IOptions<CloudinarySettings> cloudinaryConfig)
        {
            _repo = repos;
            _mapper = mapper;
            _cloudinaryConfig = cloudinaryConfig;

            Account account = new Account(
                   "dczz22okt",
                    "434637162714286",
                    "7XNM1nJlAv1QK5aZkkiFDSnJ214"
               
                
            );

             _cloudinary = new Cloudinary(account);
        }
        [HttpGet("{id}", Name = "GetPhoto")]
        public async Task<IActionResult> GetPhoto(int id)
        {
            var photoFromRepo = await _repo.GetPhoto(id);
            var photo = _mapper.Map<PhotoForReturnDto> (photoFromRepo);
            return Ok( photo);
        }
        [HttpPost]
        public async Task<IActionResult> AddPhotoForIser(int userId, [FromForm]PhotoForCreationDto photoForCreationDto ){
            if(userId != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();
            var userFromRepo = await _repo.GetUser(userId);
            var file = photoForCreationDto.File;
            var uploadResult = new ImageUploadResult();
            if(file.Length>0){
                using(var stream = file.OpenReadStream()){
                    var uploadParams= new ImageUploadParams(){
                        File = new FileDescription(file.Name, stream),
                        Transformation = new Transformation().Width(500).Height(500).Crop("fill").Gravity("face")
                    };
                    uploadResult = _cloudinary.Upload(uploadParams);
                }
            }

            photoForCreationDto.Url = uploadResult.Uri.ToString();
            photoForCreationDto.PublicId = uploadResult.PublicId;

            var photo= _mapper.Map<Models.Photo>(photoForCreationDto);
            if( !userFromRepo.Photos.Any( u => u.IsMain))
                photo.IsMain = true;

            userFromRepo.Photos.Add(photo);
          
            if(await _repo.SaveAll())
            {
                  var phototoreturn = _mapper.Map<PhotoForReturnDto>(photo);
                return CreatedAtRoute("GetPhoto",new { id = photo.Id }, phototoreturn);
                //return Ok();
            }
            return BadRequest("could not upload");
        }
        [HttpPost("{id}/setMain")]
        public async Task<IActionResult> setMainPhoto(int userId, int id) {

            if(userId != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();
            var user = await _repo.GetUser(userId);

            if(!user.Photos.Any(p => p.Id == id))
              return Unauthorized();
            
            var photoFromRepo = await _repo.GetPhoto(id);

            if( photoFromRepo.IsMain)
                return BadRequest(" already main photo");
            
            var currentMainPhoto = await _repo.GetMainPhotoForUSer(userId);

            currentMainPhoto.IsMain = false;
            photoFromRepo.IsMain = true;

            if( await _repo.SaveAll())
                return NoContent();
            
            return BadRequest(" can not set main photo");
            
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePhoto(int userId, int id){
              if(userId != int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value))
                return Unauthorized();
            var user = await _repo.GetUser(userId);

            if(!user.Photos.Any(p => p.Id == id))
              return Unauthorized();
            
            var photoFromRepo = await _repo.GetPhoto(id);

            if( photoFromRepo.IsMain)
                return BadRequest(" can not delete it is main photo");
            if(photoFromRepo.PublicID != null){
                var deleteParams = new DeletionParams(photoFromRepo.PublicID);
                var result = _cloudinary.Destroy(deleteParams);
                if(result.Result == "ok"){
                    _repo.Delete(photoFromRepo);
                }
            }
            if(photoFromRepo.PublicID == null){
                _repo.Delete(photoFromRepo);
            }
      
            if( await _repo.SaveAll())
                return Ok();

           return BadRequest(" Failed to delete the photo");
            
        }

    }
}